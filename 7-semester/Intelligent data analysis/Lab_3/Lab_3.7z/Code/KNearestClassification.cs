using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KNearestClassification : ClassificationAlgorithm
{
    public override void ExecuteAlgorithm(ref List<ClusterPoint> points, ref List<ClusterInfo> clusters)
    {
        throw new System.NotImplementedException();
    }
}
